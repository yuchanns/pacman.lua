local tiny = require "core.tiny"
local util = require "core.util"
local mattext = require "soluna.material.text"
local font = require "soluna.font"

---@type table<integer, fun(string, integer, integer): userdata>
local TEXT
local DEFAULT_TEXT_COLOR

local function init(system)
    local config = system.world.config
    local colors = config.colors
    local font_id = assert(font.name "Pacman Tiles")
    DEFAULT_TEXT_COLOR = assert(colors.COLOR_DEFAULT)

    TEXT = util.cache(function(color)
        local block = mattext.block(font.cobj(), font_id, config.tile, color, "LT")
        return block
    end)
end

local TEXT_CACHE = util.cache(function()
    return util.cache(function() return {} end)
end)

local function process(system, e)
    local queue = system.world.state.commands.queue_texts
    if #queue == 0 then return end
    local tiles = e.map.tiles
    local config = assert(system.world.config)

    for i = 1, #queue do
        local data = assert(queue[i])
        queue[i] = nil

        local x, y = assert(data.x), assert(data.y)
        local align = data.align or "left"
        local cache = TEXT_CACHE[align][data.y]
        local prev = cache[data.x]
        if prev then
            tiles[y * config.display_tile_x + prev + 1].sprite = nil
            cache[data.x] = nil
        end
        if data.text then
            if align == "right" then
                x = x - #data.text + 1
            end
            local color = data.color or DEFAULT_TEXT_COLOR
            local block = TEXT[color]
            tiles[y * config.display_tile_x + x + 1].sprite = block(data.text, #data.text * config.tile, config.tile)
            cache[data.x] = x
        end
    end
end

return tiny.processingSystem {
    filter = tiny.requireAll "map",

    priority = 3,

    onAddToWorld = init,

    process = process,
}
