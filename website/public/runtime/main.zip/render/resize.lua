local tiny = require "core.tiny"

local border <const> = 20

---@type number, number, number
local offset_x, offset_y, scale = 0, 0, 1

local function update(system)
    local queue = system.world.state.commands.queue_resize
    if #queue == 0 then return end

    local config = system.world.config
    for i = 1, #queue do
        local ev = assert(queue[i])
        queue[i] = nil
        local w, h = ev.width, ev.height
        if w and h then
            config.width = w
            config.height = h
            config.resize_dirty = true
        end
    end

    local w, h = config.width, config.height
    w = w - border
    h = h - border
    if w <= 0 or h <= 0 then
        scale = 1
        offset_x = 0
        offset_y = 0
        return
    end
    local bw = config.base_width
    local bh = config.base_height
    scale = math.min(w / bw, h / bh)
    if scale <= 0 then
        scale = 1
    end
    offset_x = (1.0 - scale) * (w * 0.5)
    offset_y = (1.0 - scale) * (h * 0.5)
end

local function preWrap(self)
    local batch = self.world.resources.batch
    batch:layer(scale, offset_x, offset_y)
end

local function postWrap(self)
    local batch = self.world.resources.batch
    batch:layer()
end

return tiny.system {
    priority = 999,

    preWrap = preWrap,
    postWrap = postWrap,

    update = update
}
